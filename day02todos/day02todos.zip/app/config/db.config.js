module.exports = {
    HOST: "localhost",
    USER: "day02todos02",
    PASSWORD: "Fn^rK@RdjC$4i#",
    DB: "day02todosdb"
  };